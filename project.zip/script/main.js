var modal = document.getElementById('myModal');
var btn = document.getElementById('myBtn');
var span = document.getElementsByClassName("close")[0];

btn.onclick = function () {
    modal.style.display = "block";
}
span.onclick = function () {
    modal.style.display = "none";
}

window.onclick = function (event) {
    if (event.target == modal) {
    modal.style.display = "none";   
    }
}

var regist = document.getElementById('myRegist');
var func = document.getElementById('myFunc');

func.onclick = function () {
    regist.style.display = "block";
}
span.onclick = function () {
    regist.style.display = "none";
}

window.onclick = function (event) {
    if (event.target == regist) {
    regist.style.display = "none";   
    }
}

var registr = document.getElementById('myRegistr');
var link = document.getElementById('myLink');

link.onclick = function () {
    registr.style.display = "block";
}
span.onclick = function () {
    registr.style.display = "none";
}

window.onclick = function (event) {
    if (event.target == registr) {
    registr.style.display = "none";   
    }
}